

## Information

- Change ownerNumber in msgHndlr.js to be your number
ownerNumber = "62812xxxxxx@c.us"
- Change adminNumber in admin.json to be your number
[] -> ["62812xxxxxx@c.us"]
- Set your limit, medialimit, prefix, etc at ./lib/setting
- Add your blacklist word at ./lib/kataksr.json but you can add manually with ${prefix}addbadword

## Contact

If you find some bugs please contact the WhatsApp number on Contact

- [Whatsapp](https://wa.me/6281281817375)
- [BOT WA](https://wa.me/6282115089860)
- [GROUP WA](https://chat.whatsapp.com/LuZkEtgJz4kI6cOkAeHL5j)

## APIKEY

Open msgHndlr.js then edit & paste it in YOUR_APIKEY
- [VHTEAR](https://api.vhtear.com)
- [MHANKBARBAR](https://mhankbarbar.herokuapp.com/api)

Open ./lib/functions.js edit vhtear with your VHTEARKEY

## Donate

- [SAWERIA](https://saweria.co/bdrsmsdn)
- [TRAKTEER](https://trakteer.id/bdrsmsdn)
- [OVO/DANA/GOPAY](081281817375)
- [BCA](8480792000) an Badra Samsudin Ramdan N
Jangan lupa follow instagramku yaa! https://instagram.com/bdrsmsdn

## Getting Started

### This project require NodeJS v14.

### Install
Clone this project

```bash
> git clone https://github.com/Angga23Bot/lucya-bot.git
> cd lucya-bot
```

Install the dependencies:

```bash
> npm install
> npm install -g pm2
```

### Usage
1. run the Whatsapp bot

```bash
> pm2 start run.js
> pm2 monit
```
2. stop the Whatsapp bot

```bash
> pm2 stop run.js
```

after running it you need to scan the qr



| All User  |              Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   Registration before use this bot                 |

| Sticker Creator |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker With Image          |
|       ✅       | Sticker With Gif                    |
|       ✅       | Sticker With Image Url                        |
|       ✅       | Sticker With Gif Url   |
|       ✅       | Image To Sticker   |
|       ✅       | Text To Picture   |
|       and       |   Others...                 |

| Downloader |                     Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   YouTube Video/Audio Downloader                    |
|       ✅        |   Doujin Downloader         |
|       ✅        |   Instagram Video/Image Downloader                  |
|       ✅        |   Facebook Video Downloader                  |
|       ✅        |  Tiktok Downloader                    |
|       ✅        |   Twitter Downloader         |
|       ✅        |   Smule Mp3 Downloader                  |
|       ✅        |   Starmaker Video Downloader                  |
|       ✅        |   Xnxx Video Downloader                  |
|       ✅        |  Joox Downloader                  |
|       ✅        |  Play Youtube in audio format              |
|       and       |   Others...                 |

| Kerang Ajaib  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Apakah             |
|       ✅        |   Bisakah                |
|       ✅        |   Rate             |
|       ✅        |   Kapankah           |

| Poll Menu  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Add Poll             |
|       ✅        |   Add Candidates               |
|       ✅        |   Vote             |
|       ✅        |   Poll Result           |

| Media  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Get a random meme             |
|       ✅        |   Text to speech                |
|       ✅        |   Get a random waifu images     |
|       ✅        |   Get a random quotes           |
|       ✅        |   Get a random anime quotes     |
|       ✅        |   Get info gempa from BMKG      |
|       ✅        |   Weather's report's     |
|       ✅        |   Wikipedia                 |
|       ✅        |   Youtube                 |
|       ✅        |   Google                 |
|       ✅        |   Pinterest    |
|       ✅        |   Anime searcher    |
|       ✅        |   Google Image               |
|       ✅        |   Couple Fortune Telling    |
|       ✅        |   Chord    |
|       ✅        |   Prayer Times    |
|       ✅        |   Lyrics    |
|       ✅        |   Textmaker    |
|       ✅        |   Instagram Stalk    |
|       ✅        |   Tiktok Stalk    |
|       ✅        |   Smule Stalk    |
|       ✅        |   Write in Image    |
|       ✅        |   Weather Information    |
|       ✅        |   Get a random cat images       |
|       ✅        |   Get a random dog images       |
|      and        |   Others...                     |


| Group Only  |                     Feature                     |
| :------------: | :---------------------------------------------: |
|       ✅        |   Promote User                  |
|       ✅        |   Demote User                   |
|       ✅        |   Kick User                     |
|       ✅        |   Add User                      |
|       ✅        |   Mention All User              |
|       ✅        |   Get link group                |
|       ✅        |   Get Admin list                |
|       ✅        |   Listblock                      |
|       ✅        |   Listbanned                      |
|       ✅        |   Listgroup                      |
|       ✅        |   Get Admin list           |
|       ✅        |   Get owner group               |
|       ✅        |   Get group info                |
|       ✅        |   enable or disable nsfw command|
|       ✅        |   enable or disable simi command|
|       ✅        |   enable or disable welcome feature|
|       ✅        |   enable or disable left feature|
|       ✅        |   enable or disable no link feature|
|       ✅        |   enable or disable no badword feature|
|       and       |   Others...                 |

| Premium Commands |              Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   Music                |
|       ✅        |   Get Music                 |
|       ✅        |   Video                 |
|       ✅        |   Get Video                 |
|       and       |   Others...                 |

| NSFW Commands |              Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   Lewds                |
|       ✅        |   Fetish                 |
|       ✅        |   Nhentai                 |
|       ✅        |   Pornhub Downloader       |
|       and       |   Others...                 |

| Anonymous Chat Commands |              Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   Registration                |
|       ✅        |   Send Message                |
|       ✅        |   List Number                 |
|       ✅        |   Remove Number       |

| Owner Group Only  |              Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   Kick All Member Group                 |

| Owner Bot Only  |              Feature                |
| :------------: | :---------------------------------------------: |
|       ✅        |   Leave all group                   |
|       ✅        |   Clear all message                 |
|       ✅        |   Broadcast                      |
|       ✅        |   Getses                      |
|       ✅        |   Banchat                      |
|       ✅        |   Maintenance                      |
|       ✅        |   Add Admin Sasha                      |
|       ✅        |   Del Admin Sasha                      |
|       ✅        |   Block                      |
|       ✅        |   Unblock                      |
|       ✅        |   Join Group                      |
|       ✅        |   Set Prefix                      |
|       ✅        |   Set Limit                      |
|       and       |  Others...                     |

---

## Troubleshooting
Make sure all the necessary dependencies are installed: https://github.com/puppeteer/puppeteer/blob/main/docs/troubleshooting.md

Fix Stuck on linux, install google chrome stable: 
```bash
> wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
> sudo apt install ./google-chrome-stable_current_amd64.deb
```

## 🙏Special Thanks To
<ul>
<li>Allah SWT<br>
<li>https://github.com/open-wa/wa-automate-nodejs<br>
<li>https://github.com/MhankBarBar/whatsapp-bot<br>
<li>https://github.com/ItzNgga/wa-bot<br>
<li>https://github.com/TobyG74<br>
<li>https://github.com/Angga23Bot<br>
</li>
